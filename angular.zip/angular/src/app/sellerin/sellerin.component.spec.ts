import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerinComponent } from './sellerin.component';

describe('SellerinComponent', () => {
  let component: SellerinComponent;
  let fixture: ComponentFixture<SellerinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
