import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyerlogout',
  templateUrl: './buyerlogout.component.html',
  styleUrls: ['./buyerlogout.component.css']
})
export class BuyerlogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
