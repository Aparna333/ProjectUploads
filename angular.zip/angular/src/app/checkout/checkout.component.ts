import { Component, OnInit } from '@angular/core';
import { Transactions, Cart, ViewCart } from '../items';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  constructor(private displaycart:ProductService) { }

  transcation:Transactions;
  transactionType:String;
  price:number;
  totalAmount:number;
  cart:Cart=new Cart();
  buyerid:any;
  trans:any;
  ngOnInit(): void {
  }

  Checkout(){
    console.log("ib checkout methid");
    this.buyerid=window.localStorage.getItem('buyerId');
    this.transcation =new Transactions();
    this.transcation.transactionType=this.transactionType;
    this.transcation.price=this.price;
    this.transcation.totalAmount=this.totalAmount;
   this.displaycart.CheckoutCart(this.transcation,this.buyerid).subscribe(newview => this.transcation=newview);
   }
}
