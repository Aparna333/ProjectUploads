import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-buyerlogin',
  templateUrl: './buyerlogin.component.html',
  styleUrls: ['./buyerlogin.component.css']
})
export class BuyerloginComponent implements OnInit {
  username:String;
  password:String;
  invalidLogin: boolean = false;
  constructor(private router:Router, private loginService:ProductService) { }

  ngOnInit(): void {
  }

  login()
  {
    console.log("in login method");
    const loginPayload = {
    username: this.username,
    password: this.password
  }
  this.loginService.buyerlogin(loginPayload).subscribe(data=>{
    debugger;
    if(data.result.token !== null) {
      alert("successs");
      console.log("in subscribe method");
      window.localStorage.setItem('token', data.result.token);
      window.localStorage.setItem('buyerId',data.result.buyerId);
      window.localStorage.setItem('username',data.result.username);
      console.log(data.result.token);
      this.router.navigate(['home']);
    }else {
      alert("incorrect password");
    }
  });
  }

}
