package com.ecart.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ecart.jpa.entity.PurchaseHistory;


@Repository
public interface PurchaseRepository extends JpaRepository<PurchaseHistory, Long> {
    
}
