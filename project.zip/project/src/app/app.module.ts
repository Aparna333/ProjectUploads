import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { SearchproductComponent } from './searchproduct/searchproduct.component';
import { NavbarComponent } from './navbar/navbar.component'; 
import { SellerComponent } from './seller/seller.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import { SellerlogoutComponent } from './sellerlogout/sellerlogout.component';
import { BuyerlogoutComponent } from './buyerlogout/buyerlogout.component';
import { AfterloginComponent } from './afterlogin/afterlogin.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductDetailsComponent,
    DisplaycartComponent,
    SearchproductComponent,
    NavbarComponent,
    SellerComponent,
    SellersignupComponent,
    BuyersignupComponent,
    LoginComponent,
    HomeComponent,
    CheckoutComponent,
    BuyerloginComponent,
    SellerlogoutComponent,
    BuyerlogoutComponent,
    AfterloginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
