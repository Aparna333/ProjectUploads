package com.ecart.jpa.entity;

public class AuthToken {

    private String token;
    private String username;

    private Long sellerId;
    
    public AuthToken(){

    }

    public AuthToken(String token, String username, Long sellerId) {
		super();
		this.token = token;
		this.username = username;
		this.sellerId = sellerId;
	}


	public AuthToken(String token){
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    public Long getSellerId() {
		return sellerId;
	}
    public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}
}
