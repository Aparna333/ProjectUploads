import { Component, OnInit } from '@angular/core';
import { Buyer } from '../items';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:String;
  password:String;
  buyer: Buyer=new Buyer();
  invalidLogin: boolean = false;
  constructor(private router:Router, private loginService:ProductService) { }

  login()
  {
    console.log("in login method");
    const loginPayload = {
    username: this.username,
    password: this.password
  }
  this.loginService.login(loginPayload).subscribe(data=>{
    debugger;
    if(data.result.token !== null) {
      alert("successs");
      console.log("in subscribe method");
      window.localStorage.setItem('token', data.result.token);
      window.localStorage.setItem('sellerId', data.result.sellerId);
      window.localStorage.setItem('username', data.result.username);
      console.log(data.result.token);
      this.router.navigate(['seller']);
    }else {
      alert("incorrect password");
    }
  });
  }
  ngOnInit() {
 }
}
