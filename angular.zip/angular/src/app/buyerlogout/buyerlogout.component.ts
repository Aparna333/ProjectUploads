import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-buyerlogout',
  templateUrl: './buyerlogout.component.html',
  styleUrls: ['./buyerlogout.component.css']
})
export class BuyerlogoutComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
window.localStorage.removeItem('token');
window.localStorage.removeItem('buyerId');
window.localStorage.removeItem('username');
this.router.navigate(['buyersignup']);
  }

}
