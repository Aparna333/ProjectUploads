import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Cart, Buyer, ViewCart, Transactions } from './items';
import { ApiResponse } from './api.response';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl='http://localhost:8989/mentorportal/buyerService/buyer/buyers';//add buyer
  private baseUrl1='http://localhost:8989/mentorportal/sellerService/item/seller/1/items';//add items in items depends on sellerId
  private baseUrl3='http://localhost:8989/mentorportal/sellerService';//add seller, delete items in seller

  private baseurl4 = 'http://localhost:8989/mentorportal/sellerService/token/generate-token';//seller
 
  private baseurl5 = 'http://localhost:8989/mentorportal/buyerService/token/generate-token';//buyer

  constructor(private http: HttpClient) { }
//Buyer
buyerlogin(loginpayload:object):Observable<ApiResponse>
    {  
      console.log("in login service method");
      console.log(loginpayload);
       return this.http.post<ApiResponse>(`${this.baseurl5}`,loginpayload);
    }
 
  addToCart(cart:Cart):Observable<any> {
    return this.http.post(`http://localhost:8989/mentorportal/buyerService/cart/buyers/1/cart`,cart);
  }

  updateCartItems(cartview:ViewCart,cartId:number) : Observable<any>{
    console.log(cartview);
    return this.http.put(`http://localhost:8989/mentorportal/buyerService/cart/buyers/1/cart/${cartId}`,cartview);
  }

  DeleteCartItem(cartId:number) : Observable<any> {
  
    return this.http.delete(`http://localhost:8989/mentorportal/buyerService/cart/${cartId}/delete`);
  }
  
  emptycart(): Observable<void> {
    return this.http.delete<void>(`http://localhost:8989/mentorportal/buyerService/cart/1/deleteall`);
  }

  CheckoutCart(transcation:Transactions,buyerId:number): Observable<any> {
  
    return this.http.post(`http://localhost:8989/mentorportal/buyerService/cart/${buyerId}/checkout`,transcation);
    window.alert("checkout done successfully");
  }

displayCartItems() : Observable<any>{
 return this.http.get(`http://localhost:8989/mentorportal/buyerService/cart/1/getAll`);
}

addbuyer(Buyer:object):Observable<any>
{  
 console.log("in last ts");
 console.log(Buyer);
 return this.http.post(`${this.baseUrl}`,Buyer);
}

//seller
//searchByItemName
getItems(itemName: string) : Observable<any> {
  console.log(itemName);
  return this.http.get(`${this.baseUrl3}/item/get/${itemName}`);
}
additems(Item:object,sellerId:any):Observable<any> 
{ 
  console.log(Item);
  return this.http.post(`http://localhost:8989/mentorportal/sellerService/item/seller/${sellerId}/items`,Item);
}

deleteitem(itemId:number):Observable<any>
{
  console.log("enter to delete");
  return this.http.delete(`${this.baseUrl3}/item/${itemId}/delete`)
}

updateitems(Item:object,itemId:number):Observable<any> 
{ 
  console.log(Item);
  console.log("in service");
  return this.http.put(`http://localhost:8989/mentorportal/sellerService/item/items/${itemId}`,Item)
}

addseller(Seller:object):Observable<any>
{ 
  console.log("in sellerservice method");
  console.log(Seller);
  return this.http.post(`${this.baseUrl3}/seller`,Seller);
}
login(loginpayload:object):Observable<ApiResponse>
    {  
      console.log("in login service method");
      console.log(loginpayload);
       return this.http.post<ApiResponse>(`${this.baseurl4}`,loginpayload);
    }
getall(sellerId:number):Observable<any>{
  return this.http.get(`http://localhost:8989/mentorportal/sellerService/item/${sellerId}/getAll`);
}

}


